everything should work just fine, any problems let me know.
just put whatever you want run in a file called stdin.txt
then include my log.txt that will print to the file the commands and time stamps

