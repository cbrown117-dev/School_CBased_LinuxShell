Chris Brown
all you need to do is type make and ./a.out 
type whatever you want after commands
