this program is simple.
type make and itll compile, then in the command line just have ./hw12 #of elements #of threads
itll run and you can check it then
