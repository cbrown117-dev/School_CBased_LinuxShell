just hit make and itll compile. run it with nthreads and nelements and you should be fine
