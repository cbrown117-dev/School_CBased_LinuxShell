This program just needs a file to read from and a blank file to write to. I have included the blank file to write to, all you need is the file to read from.
