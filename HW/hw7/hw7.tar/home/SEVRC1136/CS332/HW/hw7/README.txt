this program needs 2 command line arguements.
just two files, one to read from and one to write to.
Everything works but the ecevp seems to fail and im not sure as to why
but the time functions time and write to the other file so no problem there
