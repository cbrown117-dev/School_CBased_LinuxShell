cription:            This project is the beginning of a shell that this class is making
                        however the fork does not work and if you type too many things in the shell youll get a ./a.out warning
                        I am not sure how to fix that
Author:                 Chris Brown
Getting Started:        You just need a file to write to. I have included one called blazersh.log. Just use that.
Contact Information:    sevrc@uab.edu
